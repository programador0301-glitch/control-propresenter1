# ProControl — Control remoto de ProPresenter (APK)

App Android (WebView) que controla ProPresenter 7.9+ por la red local usando su API de red.
Incluye control de diapositivas, biblioteca/playlists, mensajes, timers, looks, macros, props y captura.

## Generar el APK (sin instalar nada)

1. Sube **todo este proyecto** a un repositorio de GitHub.
2. Ve a la pestaña **Actions** del repo. El flujo *Build APK* corre solo al subir (o dále **Run workflow**).
3. Cuando termine (✓ verde), entra a esa ejecución y descarga el artefacto **ProControl-apk** (un zip con `app-debug.apk`).
4. Pasa el `app-debug.apk` a tu celular e instálalo (activa *Instalar apps de orígenes desconocidos*).

## Uso

Abre la app, escribe la **IP** y el **puerto** (por defecto 1025) de
**ProPresenter → Preferencias → Red** (con *Enable Network API* activado), y conecta.
El teléfono y la computadora deben estar en la **misma red**.

## Notas

- Es un APK de *debug*, firmado con la clave de depuración: se instala directo, no es para la Play Store.
- Requiere ProPresenter con la API de red activada.
